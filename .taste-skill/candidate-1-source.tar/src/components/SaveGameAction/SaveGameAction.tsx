import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import type { GameData } from '../../@types/types';
import { selectIsFavorite } from '../../app/redux/selectors/favorites';
import { useAppSelector } from '../../app/hooks';
import { useAuth } from '../../hooks/useAuth';
import { buildAuthRedirectPath } from '../../lib/authRedirect';
import { removeUserFavorite, upsertUserFavorite } from '../../lib/userFavorites';

const SaveGameAction = ({ game }: { game: GameData }) => {
   const { id, name } = game;
   const navigate = useNavigate();
   const location = useLocation();
   const isItemInFavorites = useAppSelector(selectIsFavorite(id));
   const { currentUser, isAuthReady } = useAuth();
   const [isSubmitting, setIsSubmitting] = useState(false);
   const [actionError, setActionError] = useState<string | null>(null);

   const handleAuthRedirect = () => {
      const nextPath = `${location.pathname}${location.search}#game-${id}`;
      navigate(buildAuthRedirectPath(nextPath));
   };

   const addFavorites = async () => {
      if (!isAuthReady) {
         return;
      }

      if (!currentUser) {
         handleAuthRedirect();
         return;
      }

      if (isItemInFavorites || isSubmitting) {
         return;
      }

      setActionError(null);
      setIsSubmitting(true);

      try {
         await upsertUserFavorite(currentUser.uid, game);
      } catch {
         setActionError('Unable to save this game right now.');
      } finally {
         setIsSubmitting(false);
      }
   };

   const removeFavorites = async () => {
      if (!isAuthReady) {
         return;
      }

      if (!currentUser) {
         handleAuthRedirect();
         return;
      }

      if (!isItemInFavorites || isSubmitting) {
         return;
      }

      setActionError(null);
      setIsSubmitting(true);

      try {
         await removeUserFavorite(currentUser.uid, id);
      } catch {
         setActionError('Unable to remove this game right now.');
      } finally {
         setIsSubmitting(false);
      }
   };

   const buttonLabel = !isAuthReady
      ? 'Checking session...'
      : isItemInFavorites
         ? isSubmitting
            ? 'Removing...'
            : 'Remove'
         : isSubmitting
            ? 'Saving...'
            : 'Save game';

   return (
      <>
         {isItemInFavorites ? (
            <button
               className="remove-button cardButton btn"
               aria-label={`Remove ${name} from favorites`}
               onClick={() => {
                  void removeFavorites();
               }}
               disabled={!isAuthReady || isSubmitting}>
               {buttonLabel}
            </button>
         ) : (
            <button
               className="add-button cardButton btn"
               aria-label={currentUser ? `Add ${name} to favorites` : `Sign in to save ${name}`}
               onClick={() => {
                  void addFavorites();
               }}
               disabled={!isAuthReady || isSubmitting}>
               {buttonLabel}
            </button>
         )}
         {actionError ? (
            <p
               role="alert"
               className="card-error">
               {actionError}
            </p>
         ) : null}
      </>
   );
};

export default SaveGameAction;
