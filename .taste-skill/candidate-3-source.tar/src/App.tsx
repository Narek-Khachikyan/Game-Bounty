import { Route, Routes } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import Games from './page/Games';
import GameDetails from './page/GameDetails';
import Favorites from './page/Favorites';
import NotFound from './page/NotFound';
import Auth from './page/Auth';
import RequireAuth from './components/RequireAuth/RequireAuth';

function App() {
   return (
      <Routes>
         <Route path="/" element={<MainLayout />}>
            <Route index element={<Games />} />
            <Route path="/game/:id" element={<GameDetails />} />
            <Route
               path="/favorites"
               element={
                  <RequireAuth>
                     <Favorites />
                  </RequireAuth>
               }
            />
            <Route path="/auth" element={<Auth />} />
            <Route path="*" element={<NotFound />} />
         </Route>
      </Routes>
   );
}

export default App;
